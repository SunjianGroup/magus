Folder for temporary files in the test suite
