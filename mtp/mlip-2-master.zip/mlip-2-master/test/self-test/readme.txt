temp/ - a folder where temporary data is created
configurations/ - a folder with input files for testing Configuration, Neighborhood
mlips/ - a folder with input files for testing machine learning interatomic potentials and their fitting